from django.urls import path
from services import views

services_urlpatterns = ([
    path('', views.service_list, name='services'),
    path('create/', views.create, name='create'),
    path('update/<int:service_id>', views.update, name='update'),
    path('delete/<int:service_id>', views.delete, name='delete'),
], 'services')
